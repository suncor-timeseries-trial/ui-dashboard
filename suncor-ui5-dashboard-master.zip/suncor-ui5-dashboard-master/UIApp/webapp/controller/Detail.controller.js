sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("suncor.ui.UIApp.controller.Detail", {

		thingId: null,
		config: null,
		detailModel: null,
		detailViewModel: null,

		onInit: function(){
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("detail").attachPatternMatched(this._onThingMatched, this); 
			
			if(oShell.busyDialog){
				oShell.busyDialog.close();
			}
			
			this.configModel = new JSONModel();
			this.configModel.loadData("config.json");
			
			var that = this;
			
			this.configModel.attachRequestCompleted(function(){
				that.config = that.configModel.getData();
				console.log(that.config);
			});
		},
		
		_onThingMatched: function(oEvent) { 
			
			this.thingId = oEvent.getParameters().arguments.thingId;
			
			var oChart = this.getView().byId('sensorChart');
			oChart.setAssetId(this.thingId);
			
			if(this.thingId){

				this.detailModel = new JSONModel();
				
				var that = this;
				
				this.detailModel.attachRequestCompleted(function(){
					that.createUIModel();
				});
				
				var sUrl = "/backend/Snapshot(thingId='" + this.thingId + "',fromTime='',dataCategory='')";
				this.detailModel.loadData(sUrl);
			}
		},
		
		createUIModel: function(){
			
			// get snapshot data and create the ui model with it
			var snapshotData = this.detailModel.getData();
			
			var snapshotProp = this.config.tenant + "." + this.config.package + ":" + this.config.thingType;
			snapshotProp = snapshotProp.replace('-', '.').replace('-', '.').replace('-', '.');
			
			var properties = snapshotData.value[0][snapshotProp];
			//console.log(properties);
			
			var sourceInfo = null;
			var rawData = null;
			
			for(var i = 0; i < properties.length; i++){
				
				var prop = properties[i];
				
				if(prop["/RawData"]){
					rawData = prop["/RawData"];
				}
				
				if(prop["/SourceInfo"]){
					rawData = prop["/SourceInfo"];
				}
			}
			
			console.log(sourceInfo, rawData);
			
			// create table with measures view model
			var viewModelData = {
				measuresTable : {}
			};

			viewModelData.measuresTable.rows = [];
			
			for(var i = 0 ; i < rawData.length; i++){
				var data = rawData[i];
				for(var name in data){
					data = data[name];
					console.log(name, data);
				
					var row = {
						property : name,
						value : data._value,
						time : data._time,
						uom : data._unitOfMeasure
					}
	
					// rows that will be shown in table
					viewModelData.measuresTable.rows.push(row);
					
					// the 3 properties that will be shown on gauges
					if(name === "CL"){
						viewModelData.gauge1 = data._value;
					}
					
					if(name === "MOIST"){
						viewModelData.gauge2 = data._value;
					}
					
					if(name === "SHOVEL"){
						viewModelData.gauge3 = data._value;
					}
					
					// 3 markers
					if(name === "FINES"){
						viewModelData.marker1Value = data._value;
						viewModelData.marker1Label = name;
					}
					
					if(name === "D50"){
						viewModelData.marker2Value = data._value;
						viewModelData.marker2Label = name;
					}
					
					if(name === "BIT"){
						viewModelData.marker3Value = data._value;
						viewModelData.marker3Label = name;
					}
				}
			}
			
			this.detailViewModel = new JSONModel();
			this.detailViewModel.setData(viewModelData);
			
			this.getView().setModel(this.detailViewModel, "detailViewModel");
		},
		
		onThingModelerButtonPress: function(){
			window.open("https://com-iotaedemo.iot-sap.cfapps.eu10.hana.ondemand.com/launchpage/#Thing-model&/packages/com.iotaedemo.suncor.tsdata/thingtypes/SB_Type/");
		}

	});
});