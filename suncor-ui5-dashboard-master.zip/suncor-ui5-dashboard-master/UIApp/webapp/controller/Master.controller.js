sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("suncor.ui.UIApp.controller.Master", {

		selectedThingId: null,

		onInit: function(){

		},
		
		seeThing: function(oEvent){
			var thingContext = oEvent.getParameter('thing');
			//console.log(thingContext);
			
			var sPath = thingContext.getPath();
			//console.log(sPath);
			
			var thingId = sPath.replace("/Things('", '').replace("')", '');
			console.log(thingId);
			
			if(!oShell.busyDialog) {
				oShell.busyDialog = new sap.m.BusyDialog("shellBusyDialog", {
					visible : true,
					title : "Please wait",
					text: "Loading latest snapshot data for thing",
					showCancelButton: false
				});
			}
			
			if(this.selectedThingId !== thingId){
				this.selectedThingId = thingId;
				oShell.busyDialog.open();
			}
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				
			oRouter.navTo("detail", {
				thingId: thingId
			});
		},
		
		onBigDataButtonPress: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("bigdata");
		}

	});
});