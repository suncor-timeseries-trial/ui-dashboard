sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("suncor.ui.UIApp.controller.BigData", {

		config: null,
		viewModel: null,

		onInit: function(){
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("bigdata").attachPatternMatched(this._onRouteMatched, this); 
			
			var oView = this.getView();
			oView.setBusy(true); 
			
			this.dataLoad();
		},
		
		dataLoad: function(){
			
			var oView = this.getView();
			var oRangeSelect = oView.byId('dateRange');
			var d1 = oRangeSelect.getDateValue();
			var d2 = oRangeSelect.getSecondDateValue();
			
			var url = "/suncor_hana/xsodata/TIMESERIES.xsodata/CV_PI_DATA?$format=json";
			
			if(d1 && d2){
				url += "&$filter=ts gt datetime'" + d1.toISOString().replace('.000Z', '') + "'";
				url += " and ts lt datetime'" + d2.toISOString().replace('.000Z', '') + "'";
			}
			
			var that = this;
			
			var dataModel = new JSONModel();
			dataModel.attachRequestCompleted(function(){
				
				var data = dataModel.getData();
				var res = data.d.results;
				console.log(res[0]);
				
				var dataRows = [];
				
				for(var i = 0; i < res.length; i++){
					
					var dateStr = res[i].ts.replace('/Date(', '').replace(')/', '');
					//console.log(dateStr);
					
					var d = new Date(parseInt(dateStr, 10)).toISOString();
					
					var elem = {
						value : parseFloat(res[i].val),
						timestamp : d,
						property: res[i].tag
					};
					
					dataRows.push(elem);
				}
				
				if(!that.viewModel){
					that.viewModel = new JSONModel();
					that.viewModel.setSizeLimit(999999999);
				}
				
				that.viewModel.setData( {
					items : dataRows
				});
				
				oView.setModel(that.viewModel, "viewModel");
				oView.setBusy(false);
				
				MessageToast.show("Found " + dataRows.length + " records.\r\nRedrawing chart...");
				
				if(dataRows.length > 0){
					that.updateVizFrame(that, that.viewModel);
				}
				else{
					MessageToast.show("No records found !\r\nPlease select another period...");
				}
			});
			
			dataModel.loadData(url);
		},
		
		_onRouteMatched: function(oEvent) { 
			
			console.log('_onRouteMatched event');
		},
		
		updateVizFrame: function(oController, oViewModel) {
			
			var oView = oController.getView();
			var oVizFrame = oView.byId("vizFrame");
			
			var auxData = oViewModel.getData();
			
			var oModel = new sap.ui.model.json.JSONModel();
		    oModel.setData(auxData);
		    
		    var oDataset = new sap.viz.ui5.data.FlattenedDataset({
		       dimensions: [{
		         name: 'Timestamp',
		         value: "{timestamp}"
		       }],
		       measures: [
		         {
		           name: 'Value', 
		           value: '{value}' 
		         }
		       ],
		       data: {
		         path: "/items"
		       }
		     });

			if(oVizFrame.getFeeds() == 0){
			    var feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      'uid' : "axisLabels",
			      'type' : "Dimension",
			      'values' : ["Timestamp"]
			    });
	
			    var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      'uid' : "primaryValues",
			      'type' : "Measure",
			      'values' : ["Value"]
			    });
			    
    		    oVizFrame.addFeed(feedPrimaryValues);
		    	oVizFrame.addFeed(feedAxisLabels);
			}

		    oVizFrame.setVizProperties({
				plotArea : {
					dataLabel : {visible : true},
					isFixedDataPointSize : true
				},
				legend : {
					title: {visible : true}
				},
				title: {
					visible: true,
					text: 'Chart'
				}
		    });
		    
		    oVizFrame.setDataset(oDataset);
		    oVizFrame.setModel(oModel);
		},
		
		onDateRangeChange: function(){
			
		}, 
		
		onDataFilterButtonPress: function(){
			
			var oView = this.getView();
			oView.setBusy(true);
			
			this.dataLoad();
		}

	});
});